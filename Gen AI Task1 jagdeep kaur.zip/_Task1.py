# Task 1

# 1. Create a list of products
products = ["Laptop", "Shoes", "Book", "Phone", "Watch", "Bag"]

# 2. Create a tuple (product_name, price, category)
sample_product = ("Laptop", 50000, "Electronics")

# 3. Print 2nd and last product
print("2nd product:", products[1])
print("Last product:", products[-1])

# 4. Append two new products
products.append("Headphones")
products.append("Jacket")

print("Updated products list:", products)

temp_list = list(sample_product)
temp_list[1] = 55000   # change price
sample_product = tuple(temp_list)

print("Updated sample product:", sample_product)