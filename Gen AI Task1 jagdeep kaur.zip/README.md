# Product Management Tasks

This project contains 4 Python tasks:

1. Lists & Tuples
2. Sets
3. Dictionaries
4. Combined Operations

All tasks use basic Python without external libraries.