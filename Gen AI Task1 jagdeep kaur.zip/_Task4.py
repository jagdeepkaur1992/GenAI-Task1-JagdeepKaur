# Task 4 

#  product list
products = ["Bread", "Jeans", "Tablet", "Camera", "Perfume", "Shoes"]

# categories
categories = ["Food", "Clothing", "Electronics", "Electronics", "Beauty", "Footwear"]

# price dictionary
price_dict = {
    "Bread": 40,
    "Jeans": 1800,
    "Tablet": 25000,
    "Camera": 30000,
    "Perfume": 1200,
    "Shoes": 2200
}

# 1. Create catalog
catalog = []
for i in range(len(products)):
    name = products[i]
    price = price_dict[name]
    category = categories[i]
    catalog.append((name, price, category))

print("Catalog:", catalog)

# 2. category_to_products dictionary
category_to_products = {}

for name, price, category in catalog:
    if category not in category_to_products:
        category_to_products[category] = []
    category_to_products[category].append(name)

print("Category to products:", category_to_products)

# 3. Category with maximum products
max_category = max(category_to_products, key=lambda k: len(category_to_products[k]))

print("Category with most products:", max_category)
print("Products in that category:", category_to_products[max_category])