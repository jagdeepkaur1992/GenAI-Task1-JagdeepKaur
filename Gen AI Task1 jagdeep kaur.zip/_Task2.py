# Task 2

# product list 
products = ["Milk", "T-shirt", "Notebook", "Smartphone", "Sunglasses", "Backpack"]

#categories 
categories = ["Dairy", "Clothing", "Stationery", "Electronics", "Accessories", "Travel"]

# 1. Create set of categories
categories_set = set(categories)
print("Categories set:", categories_set)

# 2. Add category & show duplicates ignored
categories_set.add("Fitness")
categories_set.add("Electronics")  # duplicate

print("After adding:", categories_set)

# 3. Check if category exists
print("Is 'Travel' in set?", "Travel" in categories_set)

# Total unique categories
print("Total unique categories:", len(categories_set))