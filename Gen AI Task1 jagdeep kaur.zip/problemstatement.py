# Inventory Utility for E-commerce Store

# 1. Categories (using SET)
categories = {"Electronics", "Clothing", "Books","Footwear","Accessories","Gadgets",}

# 2. Products (using LIST of DICTIONARIES)
products = [
    {"id": 1001, "name": "Laptop", "category": "Electronics", "price": 80000, "stock": 20},
    {"id": 1002, "name": "T-Shirt", "category": "Clothing", "price": 1500, "stock": 60},
    {"id": 1003, "name": "Python Book", "category": "Books", "price": 600, "stock": 40},
    {"id": 1004, "name": "shoe", "category": "Footware", "price": 1000, "stock": 30},
    {"id": 1005, "name": "Watch", "category": "Accessories", "price": 1600, "stock": 20},
    {"id": 1006, "name": "smartphone", "category": "Gadgets", "price": 160000, "stock": 15},
    {"id": 1007, "name": "Headphones", "category": "Electronics", "price": 12000, "stock": 25},
    {"id": 1008, "name": "jeans", "category": "Clothing", "price": 1200, "stock": 75},
    {"id": 1009, "name": "java", "category": "Books", "price": 800, "stock": 10},
    {"id": 1010, "name": "sliper", "category": "Footware", "price": 1000, "stock": 30},
    {"id": 1011, "name": "Belt", "category": "Accessories", "price": 1200, "stock": 20},
    {"id": 1012, "name": "Tablet", "category": "Gadgets", "price":800000, "stock": 25},
]

# 3. Display all products

print("All Products:")
for p in products:
    print(p)

print("\nCategories:", categories)



# 4. Find products by category

search_category = "Electronics"
print("\nProducts in category:", search_category)

for p in products:
    if p["category"] == search_category:
        print(p["name"], "-", p["price"])


# 5. Low stock products

print("\nLow Stock Products (stock < 20):")

for p in products:
    if p["stock"] < 20:
        print(p["name"], "Stock:", p["stock"])


# 6. Export snapshot (using TUPLES)

print("\nProduct Snapshot:")

snapshot = []

for p in products:
    product_tuple = (p["id"], p["name"], p["price"])
    snapshot.append(product_tuple)

for s in snapshot:
    print(s)