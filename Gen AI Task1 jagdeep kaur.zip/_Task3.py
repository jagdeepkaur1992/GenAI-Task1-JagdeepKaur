# Task 3 

# 1. Create dictionary 
price_dict = {
    "Pen": 20,
    "Notebook": 80,
    "Water Bottle": 250,
    "Headphones": 1500,
    "Keyboard": 1200,
    "Mouse": 700
}

# 2. Add  product
price_dict["Speaker"] = 2000

# Update price
price_dict["Pen"] = 25

# Remove product (handle if not exists)
product_to_remove = "Charger"
if product_to_remove in price_dict:
    del price_dict[product_to_remove]
else:
    print(product_to_remove, "not found")

# 3. Average price
total = sum(price_dict.values())
count = len(price_dict)
average = total / count

print("Average price:", average)

# Extra
max_product = max(price_dict, key=price_dict.get)
min_product = min(price_dict, key=price_dict.get)

print("Max price product:", max_product, price_dict[max_product])
print("Min price product:", min_product, price_dict[min_product])